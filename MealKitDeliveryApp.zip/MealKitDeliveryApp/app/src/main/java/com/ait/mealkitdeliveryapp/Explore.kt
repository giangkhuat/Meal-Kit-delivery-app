package com.ait.mealkitdeliveryapp

import android.os.Bundle
import android.widget.Toast
import com.google.firebase.firestore.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.ait.mealkitdeliveryapp.adapter.recipeAdapter
import com.ait.mealkitdeliveryapp.data.recipe
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.EventListener
import kotlinx.android.synthetic.main.activity_explore.*


class Explore : AppCompatActivity() {

    lateinit var rAdapter: recipeAdapter
    var items  = mutableListOf<recipe>()

    // var items = AppDatabase.getInstance(this@ScrollingActivity).ItemDao().getALlItems()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_explore)
        setSupportActionBar(toolbar)

        rAdapter = recipeAdapter(this)
        var linLayoutManager = LinearLayoutManager(this)
        linLayoutManager.stackFromEnd = true

        recyclerRecipes.layoutManager = linLayoutManager
        recyclerRecipes.adapter = rAdapter
        queryPosts()

        /*
        val bottomNavigationView = bottom_navigation as BottomNavigationView
        bottomNavigationView.setOnNavigationItemSelectedListener(object :
            BottomNavigationView.OnNavigationItemSelectedListener {
            override fun onNavigationItemSelected(item: MenuItem): Boolean {
                when (item.getItemId()) {
                    action_explore -> Toast.makeText(
                        this@MainActivity,
                        "Recents",
                        Toast.LENGTH_SHORT
                    ).show()
                    R.id.action_order -> Toast.makeText(
                        this@MainActivity,
                        "Favorites",
                        Toast.LENGTH_SHORT
                    ).show()
                    R.id.action_help -> Toast.makeText(
                        this@MainActivity,
                        "Nearby",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                return true
            }
        })
        */


        //uploadRecipe()

    }

    /*
    var name : String = "",
    var ingredient : String = "",
    var description: String = "",
    var instruction: String = "",
    var nutrition : String = "",
    var category : Int = -1,
    var price : Double = 0.0
     */

    private fun uploadRecipe() {
        var recipeObj = recipe(
            /* user id */
            //FirebaseAuth.getInstance().currentUser!!.uid,
            //FirebaseAuth.getInstance().currentUser!!.displayName!!,
            "Nama Chocolate",
            "Milk, Sugar",
            "",
            "Carb a lot",
            "Dairy",
            0, 9.0
        )

        val db = FirebaseFirestore.getInstance()
        /* collection is the folder in database */
        var recipeCollection = db.collection("recipes")
        recipeCollection.add(recipeObj).addOnSuccessListener {
            Toast.makeText(this@Explore, "Success creating post", Toast.LENGTH_LONG).show()
            finish()
        }.addOnFailureListener {
            Toast.makeText(this@Explore, "Error : ${it.message}", Toast.LENGTH_LONG).show()
        }
    }


    private fun queryPosts() {
        val db = FirebaseFirestore.getInstance()
        val query = db.collection("RecipeBook")

        var allPostsListener = query.addSnapshotListener(
            object: EventListener<QuerySnapshot> {
                override fun onEvent(querySnapshot: QuerySnapshot?, e: FirebaseFirestoreException?) {

//                    if (e != null) {
//                        Toast.makeText(this@ForumActivity, "listen error: ${e.message}", Toast.LENGTH_LONG).show()
//                        return
//                    }

                    for (dc in querySnapshot!!.getDocumentChanges()) {
                        when (dc.getType()) {
                            DocumentChange.Type.ADDED -> {
                                val recipe = dc.document.toObject(recipe::class.java)
//                                recipeAdapter.addRecipe(recipe, dc.document.id)
                                rAdapter.addRecipe(recipe, dc.document.id)
                            }
                            DocumentChange.Type.MODIFIED -> {
                                Toast.makeText(this@Explore, "update: ${dc.document.id}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
            })

    }
}
