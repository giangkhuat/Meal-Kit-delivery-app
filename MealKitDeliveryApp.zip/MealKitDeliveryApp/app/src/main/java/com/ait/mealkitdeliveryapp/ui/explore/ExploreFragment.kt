package com.ait.mealkitdeliveryapp.ui.explore

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.ait.mealkitdeliveryapp.R
import com.ait.mealkitdeliveryapp.adapter.recipeAdapter
import com.ait.mealkitdeliveryapp.data.recipe
import kotlinx.android.synthetic.main.activity_explore.*
import android.widget.Toast
import com.ait.mealkitdeliveryapp.ExploreActivity
import com.google.firebase.firestore.*


class ExploreFragment : Fragment() {

    lateinit var rAdapter: recipeAdapter
    var items  = mutableListOf<recipe>()

    private lateinit var homeViewModel: HomeViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        homeViewModel =
            ViewModelProviders.of(this).get(HomeViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_explore, container, false)
        val textView: TextView = root.findViewById(R.id.text_home)
        homeViewModel.text.observe(this, Observer {
            textView.text = it
        })

        return root
    }


     fun onViewCreated() {
        // Create adapter
        rAdapter = recipeAdapter(this.context)

        var linLayoutManager = LinearLayoutManager(activity)
        linLayoutManager.stackFromEnd = true
        recyclerRecipes.layoutManager = linLayoutManager


        // Set adapter
        recyclerRecipes.adapter = rAdapter
        queryPosts()

    }



    fun queryPosts() {
        val db = FirebaseFirestore.getInstance()
        val query = db.collection("RecipeBook")

        var allPostsListener = query.addSnapshotListener(
            object: EventListener<QuerySnapshot> {
                override fun onEvent(querySnapshot: QuerySnapshot?, e: FirebaseFirestoreException?) {
                    for (dc in querySnapshot!!.getDocumentChanges()) {
                        when (dc.getType()) {
                            DocumentChange.Type.ADDED -> {
                                val recipe = dc.document.toObject(recipe::class.java)
//                                recipeAdapter.addRecipe(recipe, dc.document.id)
                                rAdapter.addRecipe(recipe, dc.document.id)
                            }
                            DocumentChange.Type.MODIFIED -> {
                                Toast.makeText(activity, "update: ${dc.document.id}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
            })

    }
}